#include <iostream>
#include <string>
#include "Fraction.h"
#include "calculate.h"
