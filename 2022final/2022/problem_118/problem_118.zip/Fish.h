#pragma once
#include"Animal.h"

class Fish : public Animal{
    public:
    Fish(int n){
        if(n == 0){
            color = "Red";
        }else{
            color = "Blue";
        }
    }

        void swim(){
        cout << color <<" fish is swiming."<<endl;
    }
    void sing(){
              cout <<"Fish can not sing."<<endl;
    }
    ~Fish(){
        cout<<color <<" bird is gone."<<endl;
    }
};